import { Component } from "@angular/core";
import { FirebaseAnalytics } from "@ionic-native/firebase-analytics/ngx";

@Component({
  selector: "app-tab2",
  templateUrl: "tab2.page.html",
  styleUrls: ["tab2.page.scss"]
})
export class Tab2Page {
  constructor(private firebaseAnalytics: FirebaseAnalytics) {}

  ionViewDidEnter() {
    console.log("ionViewDidEnter");
    this.firebaseAnalytics.setCurrentScreen("tab 2");
    console.log("tab 2");
  }

  logClick() {
    console.log("Clicked");
  }
}
